export class Cart
{
productid:number;
quantity:number;
price:number;
sellerid:number;
productname:String;
}