package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;

public interface ICartService {
	
	public String addCartItem(int buyerid,ShoppingCart cart);
	
	public List<ShoppingCart> getCart();
	
	public String deleteCartItem(int cart_id);
	
	public void emptyCart(int buyid);
	
	public String updateCart( ShoppingCart scart1,int buid);
	
	public String checkOut(Transactions transac, int buyerid);
}
