package com.example.demo.services;


import java.util.List;

import com.example.demo.Entity.Category;

public interface ICategoryService {

	List<Category> getAllCatogeris();
String addCategory(Category cat);

}
