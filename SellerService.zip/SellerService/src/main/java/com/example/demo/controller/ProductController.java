package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Product;
import com.example.demo.services.IProductService;

@RestController
@RequestMapping("/Product")
public class ProductController
{
	@Autowired
	public IProductService iprodserv;
	
	
	@PostMapping("/addProduct/{sellerid}")
	public String addProduct(@PathVariable("sellerid") int sellerid,@RequestBody Product prodetails)
	{
		return iprodserv.addProduct( sellerid,prodetails);
	}
	
@DeleteMapping("/DeleteItem/{productid}/{sellerid}")
public String deleteProduct(@PathVariable("productid") int prodid,@PathVariable("sellerid") int sellerid)
{iprodserv.deleteProduct( prodid,sellerid);
	return "Product Deleted";
}

@PostMapping("/updateProduct/{seleerid}/{productid}")
public String updateProduct(@RequestBody Product pdetails,@PathVariable("seleerid") int sellerid,@PathVariable("productid") int prodid)
{   
	iprodserv.updateProduct( pdetails,sellerid,prodid);
	return "Product Updated";
}


}
