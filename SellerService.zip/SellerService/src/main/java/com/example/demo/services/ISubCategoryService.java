package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SubCatogery;
@Service
public interface ISubCategoryService {

	List<SubCatogery> getAllSubCategories();

}
