package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.Product;

@Service
public interface IProductService {

	String addProduct(int sellerid, Product prodetails);

	void deleteProduct(int prodid, int sellerid);

	void updateProduct(Product pdetails, int sellerid, int prodid);

}
