import { Component, ViewChild } from '@angular/core';
import { StopwatchComponent } from './stopwatch.component';

@Component({
  selector: 'app-stopwatch-parent',
  templateUrl: './stopwatch-parent.component.html'
})
export class StopwatchParentComponent {
    @ViewChild(StopwatchComponent)
    private stopwatchComponent: StopwatchComponent;
	startStopwatch() {
       this.stopwatchComponent.start();
	}
	stopStopwatch() {
       this.stopwatchComponent.stop();
       }
       restartStopwatch() {
       this.stopwatchComponent.restart();
       }
       fastStopwatch() {
              console.log(11111);
       this.stopwatchComponent.fast();
       }
       slowStopwatch() {
       this.stopwatchComponent.slow();
       console.log(22222);

       }

}    