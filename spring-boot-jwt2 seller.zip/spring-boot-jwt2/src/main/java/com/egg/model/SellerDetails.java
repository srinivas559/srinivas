package com.egg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller_details")
public class SellerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer sellerid; 
	private String username;
	private String password;
	private String companyname;
	private float Gstin;
	private String companydescription;
	private String postal_address;
	private String website;
	private String emailid;
	private long contact_number;
	
	public Integer getSellerid() {
		return sellerid;
	}
	public void setSellerid(Integer sellerid) {
		this.sellerid = sellerid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public float getGstin() {
		return Gstin;
	}
	public void setGstin(float gstin) {
		Gstin= gstin;
	}
	public String getCompanydescription() {
		return companydescription;
	}
	public void setCompanydescription(String companydescription) {
		this.companydescription = companydescription;
	}
	public String getPostal_address() {
		return postal_address;
	}
	public void setPostal_address(String postal_address) {
		this.postal_address = postal_address;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getContact_number() {
		return contact_number;
	}
	public void setContact_number(long contact_number) {
		this.contact_number = contact_number;
	}
	
	public SellerDetails() {
		System.out.println("Seller Object is created");
	}
	
	public SellerDetails(Integer sellerid, String username, String password, String companyname, float gstin,
			String companydescription, String postal_address, String website, String emailid, long contact_number) {
		super();
		this.sellerid = sellerid;
		this.username = username;
		this.password = password;
		this.companyname = companyname;
        this.Gstin = gstin;
		this.companydescription = companydescription;
		this.postal_address = postal_address;
		this.website = website;
		this.emailid = emailid;
		this.contact_number = contact_number;
	}
	
	@Override
	public String toString() {
		return "SellerDetails [sellerid=" + sellerid + ", username=" + username + ", password=" + password
				+ ", companyname=" + companyname + ", Gstin=" + Gstin + ", companydescription=" + companydescription
				+ ", postal_address=" + postal_address + ", website=" + website + ", emailid=" + emailid
				+ ", contact_number=" + contact_number + "]";
	}
	
}
