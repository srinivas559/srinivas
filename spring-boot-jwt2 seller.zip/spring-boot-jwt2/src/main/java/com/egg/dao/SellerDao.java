package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.egg.model.SellerDetails;



@Repository
public interface SellerDao extends JpaRepository<SellerDetails, Integer>
{

	SellerDetails findSellerDetailsByUsername(String username);

	SellerDetails findByUsername(String username);

}
