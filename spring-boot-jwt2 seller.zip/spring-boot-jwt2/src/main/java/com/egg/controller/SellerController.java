package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.SellerDetails;
import com.egg.service.SellerService;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired(required=true)
	public SellerService sellerserv;
	
	@PostMapping(value="/addSellers",produces="application/json")
	public SellerDetails  createSeller(@RequestBody SellerDetails sdet)
	{
		return sellerserv.addSeller(sdet);
	}
	
   /* @PostMapping("/updateSeller/{sid}")
    public String updateSeller(@PathVariable("sid") Integer sellerid,@RequestBody SellerDetails sdetails)
    {
    	return sellerserv.updateSeller(sellerid,sdetails);
    }*/
    
    @GetMapping("/getAllSellers")
	public List<SellerDetails> getSellers()
	{
		return sellerserv.getSellers();
	}
}
