package com.egg.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.SellerDao;
import com.egg.model.SellerDetails;


@Service
public class SellerService implements UserDetailsService
{
	@Autowired
	public SellerDao sdao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public SellerDetails addSeller(SellerDetails sdetails)
	{
		sdetails.setPassword(bcryptEncoder.encode(sdetails.getPassword()));
		return sdao.save(sdetails);
	}


	public String updateSeller(Integer sellerid, SellerDetails sdetails)
	{
		SellerDetails sdet=sdao.getOne(sellerid);//getone item
		String usname=sdetails.getUsername();
		 String pass=sdetails.getPassword();
		 String compname=sdetails.getCompanyname();
		 float gstin=sdetails.getGstin();
		 String compdescription=sdetails.getCompanydescription();
		 String postaddres=sdetails.getPostal_address();
		 String site=sdetails.getWebsite();
		 String emailid=sdetails.getEmailid();
		 long contactnumber=sdetails.getContact_number();
		 sdet.setUsername(usname);
		 sdet.setPassword(pass);
		 sdet.setCompanyname(compname);
		 sdet.setGstin(gstin);
		 sdet.setCompanydescription(compdescription);
		 sdet.setPostal_address(postaddres);
		 sdet.setWebsite(site);
		 sdet.setEmailid(emailid);
		 sdet.setContact_number(contactnumber);
		 System.out.println(sdet);
		 sdao.save(sdet);
		return "\"Seller Details Updated\"";
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		SellerDetails user = sdao.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	
	
	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	


	public SellerDetails findOne(String username) {
		
		return sdao.findSellerDetailsByUsername(username);
	}

	public List<SellerDetails> getSellers() {
	
	return sdao.findAll();
	}

}
