package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;


public interface IStudentService{

	public List<Student> getAllPersons();
	public Optional<Student> getPersonById(int id);
	public Student getPersonByName(String name) ;
	public Student findUsingNameAddr(String name,String addr);
	
}
