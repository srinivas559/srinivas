package com.cts.springbootjpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface IStudentDao  extends JpaRepository<Student, Integer> {

	@Query(value="FROM Person p where p.personName =:pn")
	public Student findByPersonName(@Param("pn") String name);
	
	@Query(value="FROM Person p where p.personName =:pn and p.addr=:addr")
	public Student findUsingNameAddr(@Param("pn")String n, @Param("addr") String ad);
}
