package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	private IStudentDao dao;//entity mgr factory
	
	@Override
	public List<Student> getAllPersons() {
	
		return dao.findAll();
				
	}

	@Override
	public Optional<Student> getPersonById(int id) {
		
		return dao.findById(id);
	}
	@Override
	public Student getPersonByName(String name) {
		
			return dao.findByPersonName(name);
	}
	@Override
	public Student findUsingNameAddr(String name,String addr){
		return dao.findUsingNameAddr(name,addr);
	}
	
}
