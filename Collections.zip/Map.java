/* this is Java map in and prints the values  given hardcoded values  author=srinivas*/


import java.util.*;  
class MapExample1{  
 public static void main(String args[]){  
  Map<Integer,String> map=new HashMap<Integer,String>();  
  map.put(100,"srinivas");  
  map.put(101,"vijay");  
  map.put(102,"rahul"); 
   map.put(103,"ravi");
  //Elements can traverse in any order  
  for(Map.Entry m:map.entrySet()){  
   System.out.println(m.getKey()+" "+m.getValue());  
  }  
 }  
}  