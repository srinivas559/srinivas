/* this is tree set in collections and does not print duplicates author=srinivas*/

import java.util.*;  
public class TestJavaCollection9{  
public static void main(String args[]){  
TreeSet<String> set=new TreeSet<String>();  
set.add("srinivas");  
set.add("vikas");  
set.add("srinivas");  
set.add("ajay");
set.add("ravi");
set.add("vijay");  
Iterator<String> itr=set.iterator();  
while(itr.hasNext()){  
System.out.println(itr.next());  
}  
}  
}  