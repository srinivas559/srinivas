package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee implements Serializable{
	
	@Id
	private int empId;
	//@Column(name="Employee_Name")
	private String empname;
	private String desig;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpame() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public Employee()
	{
		
	}
	public Employee(int empId, String empname, String desig) {
		super();
		this.empId = empId;
		this.empname = empname;
		this.desig = desig;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empname=" + empname + ", desig=" + desig + "]";
	}
	
	

}
