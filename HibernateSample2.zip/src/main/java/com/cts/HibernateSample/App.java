package com.cts.HibernateSample;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.Model.Employee;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration configuration=new Configuration().configure();
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
        SessionFactory factory = configuration.buildSessionFactory(builder.build());
        Session session = factory.openSession();
        
        
        Employee emp=new Employee(1003,"larvel","Manager");
        session.beginTransaction();
       
        emp.setEmpname("Rahul");
        emp.setDesig("sr mgr");
        Serializable ob=session.save(emp);
        session.getTransaction().commit();
        System.out.println(emp);
        System.out.println(ob);
        session.close();
        
    	//session.delete(e);
    	//session.flush();
    	session.getTransaction().commit();
    }
}
