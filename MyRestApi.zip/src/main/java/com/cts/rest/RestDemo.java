package com.cts.rest;

import java.util.*;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestDemo {
	
	List<Product> newList = new ArrayList<>();
	Map<Integer,Product> newMap = new HashMap<>();
	
	public RestDemo() {
		//ListObjects
		newList.add(new Product("TV", 1001, 7, 34254.23f));
		newList.add(new Product("TV", 1002, 5, 3354.23f));
		newList.add(new Product("TV", 1003, 6, 3254.23f));
		newList.add(new Product("TV", 1004, 1, 4254.23f));
		//MapObjects
		newMap.put(1001, new Product("TV", 1001, 7, 34254.23f));
		newMap.put(1002, new Product("TV", 1002, 5, 3354.23f));
		newMap.put(1003, new Product("TV", 1003, 6, 3254.23f));
		newMap.put(1004, new Product("TV", 1004, 1, 4254.23f));
	}
	
	
	@RequestMapping("/data")
	public String getIndex() {
		return "simple data";
	}
	
	
	@RequestMapping("/jsondata")
	public String getString() {
		return "{\"payroll\":\"success\",\"data\":\"json\"}";
	}
	
	
	@RequestMapping("/jsonProdList")
	public List<Product> getProductList() {
		return newList;
	}
	
	
	@RequestMapping("/jsonProdMap")
	public Map<Integer,Product>getProdMap() {
		return newMap;
	}
	
	//If u want to check through URL, use GET
	@RequestMapping(value="/getbyid/{pid}", method=RequestMethod.POST) 
	public Product getById(@PathVariable("pid") int id) {
		return newMap.get(id);
	}

}
