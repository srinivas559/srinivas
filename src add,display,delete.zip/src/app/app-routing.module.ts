import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SearchitemsComponent} from './searchitems/searchitems.component';
import {DisplaycartComponent} from './displaycart/displaycart.component'
const routes: Routes = [ 
  {path : 'searchitems',component:SearchitemsComponent},
  {path : 'displaycart' , component:DisplaycartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
