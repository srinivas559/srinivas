import { Component, OnInit } from '@angular/core';
import {Cart} from '../Shoppingcart';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {

  displayCart:Cart[];
  constructor(private displaycart:BuyerServiceService) { }

  ngOnInit(): void {
    this.displaycart.displayCartItems().subscribe( displayCart => this.displayCart=displayCart);
    console.log(this.displayCart);
  }

deleteItem()
{
  this.displaycart.deleteCartItem().subscribe( displayCart => this.displayCart=displayCart);
}


  onSubmit()
  {
this.deleteItem();
  }
  onSub()
  {
    this.displaycart.emptyCart().subscribe( displayCart => this.displayCart=displayCart);
  }
}
