package com.areyes1.jgc.mockito.e;

// TODO: Auto-generated Javadoc
/**
 * The Class TestService.
 */
public class TestService {

	
	private MyInterface mint;
	public TestService(MyInterface mint)
	{
		this.mint=mint;
	}
	/**
	 * Gets the unique id.
	 *
	 * @return the unique id
	 */
	
	public int getUniqueId() {
		mint.sum(10, 20);
		return 43;
	}
	
	public int testing(int num) {
		someMethod("");
		return num;
	}
	
	public void someMethod(String someMethod) {
		testing(1);
	}
}
