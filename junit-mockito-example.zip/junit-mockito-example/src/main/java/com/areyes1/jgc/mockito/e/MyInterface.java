package com.areyes1.jgc.mockito.e;

public interface MyInterface {
 int sum(int a,int b);
}
