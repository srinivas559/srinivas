 package com.areyes1.jgc.mockito.e;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;

/**
 * The Class JUnitServiceTestExample.
 */
public class JUnitServiceTestExample {

	/**
	 * Test1.
	 */
	@Test
	public void testSimpleInt() {
		// create mock
		MyInterface mint = Mockito.mock(MyInterface.class);
		
		when(mint.sum(10, 20)).thenReturn(30);
		
        TestService ts=new TestService(mint);
        
		// define return value for method getUniqueId()
		
		// use mock in test....
		assertEquals(ts.getUniqueId(), 43);
	}

	/**
	 * Test more than one return value.
	 */
	// Demonstrates the return of multiple values
	@Test
	public void testMoreThanOneReturnValue() {
		Iterator i = mock(Iterator.class);
		when(i.next()).thenReturn("Mockito").thenReturn("is neat!!");
		String result = i.next() + " " + i.next();
		assertEquals("Mockito is neat!!", result);
	}

	/**
	 * Test return value dependent on method parameter.
	 */
	@Test
	public void testReturnValueDependentOnMethodParameter() {
		Comparable c = mock(Comparable.class);
		when(c.compareTo("Mockito")).thenReturn(1);
		when(c.compareTo("Eclipse")).thenReturn(2);
		// assert
		assertEquals(1, c.compareTo("Mockito"));
	}

	/**
	 * Test return value in dependent on method parameter.
	 */
	@Test
	public void testReturnValueInDependentOnMethodParameter() {
		Comparable c = mock(Comparable.class);
		when(c.compareTo(anyInt())).thenReturn(-1);
		assertEquals(-1, c.compareTo(9));
	}
}
