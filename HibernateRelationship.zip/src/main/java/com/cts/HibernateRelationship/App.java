package com.cts.HibernateRelationship;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.Model.Order;
import com.cts.Model.OrderItem;


public class App 
{
    public static void main( String[] args )
    {
    	Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		 session.beginTransaction();
		 Order odr=new Order();
		odr.setDescription("Hello this is srinivas");
		OrderItem oi=new OrderItem();
		oi.setOrderItemId(101);
		oi.setQuantity(4);
		
		odr.setOrderitem(oi);
		oi.setOrder(odr);
		
		
		session.save(odr);
		session.getTransaction().commit();
		session.close();
    }
}
