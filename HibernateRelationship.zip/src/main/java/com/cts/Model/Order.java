package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Order2")
public class Order implements Serializable {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private int orderId;
 private String description;
 
 @OneToOne
 private OrderItem orderitem;
 
 public OrderItem getOrderitem() {
	return orderitem;
}
public void setOrderitem(OrderItem orderitem) {
	this.orderitem = orderitem;
}

public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
 
 

public Order()
{
	 
}

public Order(int orderId, String description) {
	super();
	this.orderId = orderId;
	this.description = description;
}

@Override
public String toString() {
	return "Order [orderId=" + orderId + ", description=" + description + "]";
}
 
	
}
