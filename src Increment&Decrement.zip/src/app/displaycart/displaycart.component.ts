import { Component, OnInit } from '@angular/core';
import {Cart} from '../Shoppingcart';
import { BuyerServiceService } from '../buyer-service.service';


@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
  initialCount: number = 0;
  count:number = 0;
  displayCart:Cart[];
  constructor(private displaycart:BuyerServiceService) { }

  ngOnInit(): void {
    this.displaycart.displayCartItems().subscribe( displayCart => this.displayCart=displayCart);
    console.log(this.displayCart);
  }
  increase() {
    this.count++;
  }
  
  decrease() {
    this.count--;
  }

  onSubmit()
  {
    this.displaycart.deleteCartItem().subscribe( displayCart => this.displayCart=displayCart);
  }
  onSub()
  {
    this.displaycart.emptyCart().subscribe( displayCart => this.displayCart=displayCart);
  }
}
