export class Cart
{
productid:number;
quantity:number;
total_price:number;
sellerid:number;
productname:String;
}