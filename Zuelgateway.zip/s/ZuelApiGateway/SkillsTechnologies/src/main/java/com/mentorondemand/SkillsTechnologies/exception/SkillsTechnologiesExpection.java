/**
 * 
 */
package com.mentorondemand.SkillsTechnologies.exception;


public class SkillsTechnologiesExpection {

}
