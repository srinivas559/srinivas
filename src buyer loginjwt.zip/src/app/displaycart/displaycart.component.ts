import { Component, OnInit } from '@angular/core';
import {Cart, ShopCart} from '../Shoppingcart';
import { BuyerServiceService } from '../buyer-service.service';
import { Product } from '../Items';
import { element } from 'protractor';


@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
  
  displayCart:ShopCart[];
  totalprice:number=0;
  dis:Product[];
  scart : ShopCart =new ShopCart();
  fare:number;
  
  constructor(private displaycart:BuyerServiceService) { }

  ngOnInit(): void {
    this.showCartItems();

}

showCartItems(): void{
  this.displayCart
  this.displaycart.displayCartItems().subscribe( displayCart => {this.displayCart=displayCart;
    this.totalprice=0;
    this.displayCart.forEach(element =>{
      this.totalprice=this.totalprice+element.total_price*element.quantity;
    });
  console.log(this.displayCart);
}
  );
}
  increase(incart:ShopCart) {
  
    incart.quantity +=1;
    //incart.total_price=incart.quantity * this.totalprice;
    console.log(incart.quantity);
    console.log(incart);
    this.displaycart.updateCartItems(incart).subscribe(newview => this.scart=newview);
    this.showCartItems();
    alert("Quantity Value incremented");
  }
  
  decrease(dcart:ShopCart) {
    if(dcart.quantity>0)
    dcart.quantity -=1;
    //dcart.total_price=dcart.quantity * this.fare;
    this.displaycart.updateCartItems(dcart).subscribe(newview => this.scart=newview);
    this.showCartItems();
    alert("Quantity Value decremented");
  }

  onSubmit()
  {
    this.displaycart.deleteCartItem().subscribe( displayCart => this.displayCart=displayCart);
    alert("Item deleted");
  }
  onSub()
  {
    this.displaycart.emptyCart().subscribe( displayCart => this.displayCart=displayCart);
  }
  
  
}
