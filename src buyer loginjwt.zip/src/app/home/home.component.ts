import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { BuyerServiceService } from '../buyer-service.service';
import { Product } from '../Items';
import { ShopCart } from '../Shoppingcart';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  displayCart:Product[];
  decription: String;

constructor(private cartService:BuyerServiceService) { }

  ngOnInit(): void {
    this.cartService.getCartItems().subscribe( displayCart => this.displayCart =displayCart);
  }
 

  onSubmit()
  {
    {{this.decription}};
  }
}
