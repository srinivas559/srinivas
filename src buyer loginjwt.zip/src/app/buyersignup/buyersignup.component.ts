import { Component, OnInit } from '@angular/core';
import { User } from '../Buyer';
import { BuyerServiceService } from '../buyer-service.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyersignup',
  templateUrl: './buyersignup.component.html',
  styleUrls: ['./buyersignup.component.css']
})
export class BuyersignupComponent implements OnInit {
  buyer: User= new User();
  constructor(private database:BuyerServiceService,private router: Router) { }

  ngOnInit(): void {
  }

  addBuyer(){
    console.log(this.buyer);
    this.database.createbuyer(this.buyer)
    .subscribe(buyer=>this.buyer=buyer);
    this.router.navigate(['buyerlogin']);
  }
onSubmit(form:NgForm){
    
    this.addBuyer();
    alert("User successfully registered you be redirected to login page");
    
}
}
