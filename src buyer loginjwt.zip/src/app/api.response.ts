export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }
  