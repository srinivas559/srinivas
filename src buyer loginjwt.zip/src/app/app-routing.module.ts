import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DisplaycartComponent} from './displaycart/displaycart.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { HomeComponent } from './home/home.component';
import { BuyerlogoutComponent } from './buyerlogout/buyerlogout.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
const routes: Routes = [ 
  {path : 'buyersignup',component:BuyersignupComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path: 'buyer-signup', component: BuyersignupComponent},
  { path: 'buyerlogin', component: BuyerloginComponent},
  { path: 'Home', component: HomeComponent},
  { path: 'buyerlogout', component: BuyerlogoutComponent},
  { path: 'checkout', component: CheckoutComponent},
  { path: 'history', component:  PurchasehistoryComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
