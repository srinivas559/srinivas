export class User
{
    emailid:String;
    mobile_number:number;
    password:String;
    username:String;
}
    