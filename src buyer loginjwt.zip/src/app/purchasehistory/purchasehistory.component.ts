import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { PurchaseHistory } from '../history';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchasehistoryComponent implements OnInit {
purchase:PurchaseHistory=new PurchaseHistory();
  constructor(private displaycart:BuyerServiceService) { }

  ngOnInit(): void {
    this.displaycart.getPurchaseHistory().subscribe( purchase => this.purchase=purchase);
  }


  /*onSubmit()
  {
    
  }*/
}
