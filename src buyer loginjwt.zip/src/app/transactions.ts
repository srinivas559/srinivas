export class Transaction
{
    transaction_type:String;
    remarks:String;
}