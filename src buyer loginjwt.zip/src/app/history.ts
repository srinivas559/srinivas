export class PurchaseHistory
{
    purchase_Id:number;
    number_of_items:number;
    price:number;
}