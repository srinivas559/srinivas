package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.SellerDao;
import com.example.demo.entity.SellerDetails;

@Service
public class SellerService implements ISellerService
{
	@Autowired
	public SellerDao seldao;

	@Override
	public String createSeller(SellerDetails sdet)
	{
		seldao.save(sdet);
		return "\"Seller Account Created\"";
	}
	
	@Override
	public String updateSeller(Integer sellerid, SellerDetails sdetails)
	{
		SellerDetails sdet=seldao.getOne(sellerid);
		String usname=sdetails.getUsername();
		 String pass=sdetails.getPassword();
		 String compname=sdetails.getCompanyname();
		 float gstin=sdetails.getGstin();
		 String compdescription=sdetails.getCompanydescription();
		 String postaddres=sdetails.getPostal_address();
		 String site=sdetails.getWebsite();
		 String emailid=sdetails.getEmailid();
		 long contactnumber=sdetails.getContact_number();
		 sdet.setUsername(usname);
		 sdet.setPassword(pass);
		 sdet.setCompanyname(compname);
		 sdet.setGstin(gstin);
		 sdet.setCompanydescription(compdescription);
		 sdet.setPostal_address(postaddres);
		 sdet.setWebsite(site);
		 sdet.setEmailid(emailid);
		 sdet.setContact_number(contactnumber);
		return "\"Seller Details Updated\"";
	}

}
