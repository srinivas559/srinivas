package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.SellerDetails;
import com.example.demo.service.ISellerService;




@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	public ISellerService iserv;
	
	
	@PostMapping("/createseller")
	public String createSeller(@RequestBody SellerDetails sdetails)
	{
		return iserv.createSeller(sdetails);
	}
    @PostMapping("/updateSeller/{sid}")
    public String updateSeller(@PathVariable("sid") Integer sellerid,@RequestBody SellerDetails sdetails)
    {
    	return iserv.updateSeller(sellerid,sdetails);
    }
}
