package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.SellerDetails;



@Service
public interface ISellerService {

	public String createSeller(SellerDetails sdetails);
    public String updateSeller(Integer sellerid, SellerDetails sdetails);

}
