package com.cts.jdbc.Spring_Jdbc;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

//jdbctemplate
// connection pooling - prob

public class App {
	public static void main(String[] args) {

	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
	DataSource ds=(DataSource)ctx.getBean("ds");
	
	JdbcTemplate jdbc=null;
	jdbc=new JdbcTemplate(ds);
	
	List<Product> list=jdbc.query("select * from Product",new ProductRowmapper());
	//List<Map<String, Object>> list=jdbc.queryForList("select * from Product");
	
	list.stream().forEach(System.out::println);
	//Simplejdbctemplate, NamedParameterJdbcTemplate
	
	//inner class - RowMapper , anonymous class
	
	// ResultSetExtracter
	
	//preparedstatementcallback
	
	}
	
}

class ProductRowmapper implements RowMapper<Product>{

	Product product=null;
	@Override
	public Product mapRow(ResultSet rs, int arg1) throws SQLException {
		System.out.println();
		product=new Product(rs.getInt(1), rs.getString(2), rs.getInt(3),rs.getFloat(4));
		return product;
	}

	
}


















