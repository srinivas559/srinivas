package com.egg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.egg.model.Buyer;


public interface UserDao extends JpaRepository<Buyer, Integer>
{

	public Buyer findBuyerByUsername(String Username);

}
