package com.egg.service;

import java.util.List;

import com.egg.model.Buyer;



public interface IBuyerService {

	//public List<Product> getAllProducts();
	
	public String addProduct(Buyer buyer);
	
	public List<Buyer> getUsers();
	
	public String findByIdAndPostId(int buyerid);
}
