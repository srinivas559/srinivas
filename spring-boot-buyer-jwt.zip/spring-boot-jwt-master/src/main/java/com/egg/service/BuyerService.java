package com.egg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.egg.dao.UserDao;
import com.egg.model.Buyer;


@Service
public class BuyerService implements IBuyerService{
	
	
	

	
	@Autowired
	public UserDao udao;
	
	/*
	 * public List<Product> getAllProducts() {
	 * 
	 * return dao.findAll(); }
	 */
	public String addProduct(Buyer buyer) {
		
		 udao.save( buyer);
		return "/User Added/";
	}

	public List<Buyer> getUsers() {
		
		return udao.findAll();
	}
	public String findByIdAndPostId(int buyerid) {
		udao.deleteById(buyerid);
		return "/User Deleted/";
	}

	public Buyer findOne(String username) {
		// TODO Auto-generated method stub
		return udao.findBuyerByUsername(username);
	}

	/*
	 * public Buyer findOne(String username) { // TODO Auto-generated method stub
	 * return null; }
	 */
	

}

