import { Component } from '@angular/core';
import {User} from'./users';
import {RemoveSpaces} from './remove-space';

@Component({
  selector: 'app-root',
  styles: [`
    .app {
      display: block;
      text-align: center;
      padding: 25px;
      background: #f5f5f5;
    }
  `],
  template: `
    <div class="app">
      Parent: {{ myCount }}
      <counter
        [count]="myCount"
        (change)="countChange($event)">
      </counter>
    </div>
  `
})

export class AppComponent {
  // title = 'my-app2';
  // isValid = true;
  // ids = [1,2,3,4,5];
  // count =0;

//   Users: User[]= [
//     new User('Mahesh', 20,'abc@12'),
//     new User('Krishna', 22,'zxt@123'),
//     new User('Narendra', 31,'asx@12')
//   ]

//   name:string="abcdef";
//   welcomeText:string;

//   constructor()
//   {
//     this.name='pink';
//     this.welcomeText="You are Welcome";
//     console.log('aaaaaaa');
//   }
//  shide(){
//     this.isValid=!this.isValid;
//   }
  
//   even()
//   {
//     this.count++;
//   }
    
//   value;
//    clicked(){
//          this.count++;
//          switch(this.count)
//     {
      
//         case 1:
//         this.value= 'one';
//         break;
//         case 2:
//         this.value= 'two';
//         break;
//         case 3:
//         this.value= 'three';
//         break;
//         case 4:
//           this.count = 1;
//         this.value= 'one';
//         break;
//     }
  
//   }
  // export class CounterComponent {
  
    myCount: number = 10;
    countChange(event) {
      this.myCount = event;
    }
 
}