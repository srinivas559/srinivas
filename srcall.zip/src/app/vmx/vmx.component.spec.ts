import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VmxComponent } from './vmx.component';

describe('VmxComponent', () => {
  let component: VmxComponent;
  let fixture: ComponentFixture<VmxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VmxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VmxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
