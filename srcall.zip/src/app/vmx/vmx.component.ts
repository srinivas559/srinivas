import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vmx',
  templateUrl: './vmx.component.html',
  styleUrls: ['./vmx.component.css']
})
export class VmxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  ids=[1,2,3,4,5];
}
