package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CartDao;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Buyer;
import com.example.demo.entity.ShoppingCart;

@Service
public class CartService {
	
	@Autowired
	public CartDao cdao;
	@Autowired
	public UserDao udao;
	
	public String addCartItem(int buyerid,ShoppingCart cart)
	{
		Buyer br=udao.getOne(buyerid);
		cart.setUser(br);
		System.out.println("cart");
		cdao.save(cart);
		
		return "\"Item added\"";
	}
	public List<ShoppingCart> getCart()
	{
		System.out.println("In CartService");
		return cdao.findAll();
	}
	
	public String deleteCartItem(int cart_id)
	{
		cdao.deleteById(cart_id);
		return "\" Item Deleted from te cart\"";
	}


}
