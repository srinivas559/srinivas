package com.example.demo.entity;

import java.util.List;

import javax.persistence.*;

@Entity
public class ShoppingCart {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int cart_Id;
private int quantity;
private float total_price;
private int productid;


@ManyToOne
@JoinColumn(name = "buyerid")
private Buyer user;


public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}

public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public Buyer getUser() {
	return user;
}
public void setUser(Buyer user) {
	this.user = user;
}

public int getCart_Id() {
	return cart_Id;
}

public void setCart_Id(int cart_Id) {
	this.cart_Id = cart_Id;
}
public int getQuatity() {
	return quantity;
}
public void setQuatity(int quantity) {
	this.quantity = quantity;
}
public float getTotal_price() {
	return total_price;
}
public void setTotal_price(float total_price) {
	this.total_price = total_price;
}

public ShoppingCart() {
	System.out.println("ShoppingCart Object Has been Created");
}

public ShoppingCart(int cart_Id, int quantity, float total_price, int productid, Buyer user) {
	super();
	this.cart_Id = cart_Id;
	this.quantity = quantity;
	this.total_price = total_price;
	this.productid = productid;
	this.user = user;
}

@Override
public String toString() {
	return "ShoppingCart [cart_Id=" + cart_Id + ", quantity=" + quantity + ", total_price=" + total_price
			+ ", productid=" + productid + ", user=" + user + "]";
}



}
