package com.example.demo.entity;

import java.util.Date;

import javax.persistence.*;

@Entity
public class PurchaseHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchase_Id;
	/*private int Buyer_id;
	private int Seller_id;
	private int Transaction_id;
	private int Item_id;*/
	@ManyToOne
	@JoinColumn(name = "buyer_id")
	private Buyer user;
	private int Number_of_items;
	@Temporal(TemporalType.TIMESTAMP)
	private Date Date_time;
	
	public Buyer getUser() {
		return user;
	}
    public void setUser(Buyer user) {
		this.user = user;
	}
    public int getPurchase_Id() {
		return purchase_Id;
	}
	public void setPurchase_Id(int purchase_Id) {
		this.purchase_Id = purchase_Id;
	}
	public int getNumber_of_items() {
		return Number_of_items;
	}
	public void setNumber_of_items(int number_of_items) {
		Number_of_items = number_of_items;
	}

	public Date getDate_time() {
		return Date_time;
	}

	public void setDate_time(Date date_time) {
		Date_time = date_time;
	}
	
	
	
	public PurchaseHistory() {
		System.out.println("Purchase Histoty Object Has been created");
	}
	
	public PurchaseHistory(int purchase_Id, Buyer user, int number_of_items, Date date_time) {
		super();
		this.purchase_Id = purchase_Id;
		this.user = user;
		Number_of_items = number_of_items;
		Date_time = date_time;
	}

    @Override
	public String toString() {
		return "PurchaseHistory [purchase_Id=" + purchase_Id + ", user=" + user + ", Number_of_items=" + Number_of_items
				+ ", Date_time=" + Date_time + "]";
	}

}
