import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyersignup',
  templateUrl: './buyersignup.component.html',
  styleUrls: ['./buyersignup.component.css']
})
export class BuyersignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
