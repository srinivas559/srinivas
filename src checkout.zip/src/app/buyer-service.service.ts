import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Cart, ShopCart } from './Shoppingcart';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  

  private baseUrl="http://localhost:8082/product";
  private baseUrl1="http://localhost:8081/cart/addItem/2";
  constructor(private http:HttpClient ) { }
  getItemsByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getMatchItems`+`/${productName}`);
  }

  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`,cart);
  }
  
  displayCartItems() : Observable<any>{

    return this.http.get(`http://localhost:8081/cart/getItems`);
 
  }
  deleteCartItem() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/deleteItem/16`);
  }
  
  emptyCart() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/emptyCart/2`);
  }


  updateCartItems(incart: ShopCart) :Observable<any>{
    console.log("jfshjsg");
    console.log(incart);
   return this.http.post(`http://localhost:8081/cart/updatecart/4`,incart);
  }

  checkOutCart(checkout:ShopCart) :Observable<any>
  {
    return this.http.post(`http://localhost:8081/cart/checkout/4`,checkout);
 
  }
}