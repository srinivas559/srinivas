import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddcartComponent } from './addcart/addcart.component';
import { SearchitemsComponent } from './searchitems/searchitems.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { UpdatecartComponent } from './updatecart/updatecart.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';


@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent,
    SearchitemsComponent,
    DisplaycartComponent,
    UpdatecartComponent,
    BuyersignupComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
