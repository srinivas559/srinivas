package com.example.demo.Entity;

import javax.persistence.*;

@Entity
public class SubCategory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer subcategory_id;
	private String subcategory_name;
	
	@ManyToOne//category_id
	@JoinColumn(name="category_id")
	private Category cat;
	
	private String brief_details;
	private float GST;
	

	
	
	
	
	
	public Category getCat() {
		return cat;
	}
	public void setCat(Category cat) {
		this.cat = cat;
	}
	public Integer getSubcategory_id() {
		return subcategory_id;
	}
	public void setSubcategory_id(Integer subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategory_name() {
		return subcategory_name;
	}
	public void setSubcategory_name(String subcategory_name) {
		this.subcategory_name = subcategory_name;
	}
	public String getBrief_details() {
		return brief_details;
	}
	public void setBrief_details(String brief_details) {
		this.brief_details = brief_details;
	}
	public float getGST() {
		return GST;
	}
	public void setGST(float gST) {
		GST = gST;
	}

	public SubCategory() {
		System.out.println("Sub_Category Object has been created");
	}
	
	public SubCategory(Integer subcategory_id, String subcategory_name, Category cat, String brief_details, float gST) {
		super();
		this.subcategory_id = subcategory_id;
		this.subcategory_name = subcategory_name;
		this.cat = cat;
		this.brief_details = brief_details;
		GST = gST;
	}
	
	@Override
	public String toString() {
		return "SubCategory [subcategory_id=" + subcategory_id + ", subcategory_name=" + subcategory_name + ", cat="
				+ cat + ", brief_details=" + brief_details + ", GST=" + GST + "]";
	}



	
	
	

}
