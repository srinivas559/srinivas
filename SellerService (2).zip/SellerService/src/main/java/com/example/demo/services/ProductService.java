package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.Entity.Product;
import com.example.demo.Entity.SellerDetails;
import com.example.demo.Entity.SubCategory;
import com.example.demo.repositry.ProductDao;
import com.example.demo.repositry.SellerDao;
import com.example.demo.repositry.SubCategoryDao;

@Service
public class ProductService implements IProductService
{
    @Autowired
    private ProductDao pdao;
    @Autowired
    private SellerDao sdao;
    @Autowired
    private SubCategoryDao subdao;
    
    
    @Override
    public List<Product> getAllProducts()
    {
    	return pdao.findAll();
    }

	@Override
	public String addProduct(int category_id,int sellerid,Product prodetails) 
	{     
		
		
		
		
		  SellerDetails sdetails=sdao.getOne(sellerid); 
		  System.out.println(sdetails);
		  prodetails.setSdetails(sdetails);
		  
		  SubCategory scat=subdao.getOne(category_id); 
		  System.out.println(scat);
		  prodetails.setScategory(scat);
		  
		  pdao.save(prodetails);
		  System.out.println(prodetails);
		  
		 
		return "Product added";
	}

	@Override
	public void deleteProduct(int prodid, int sellerid) {
		pdao.deleteProduct(prodid,sellerid);
		
		
	}

	@Override
	public void updateProduct(Product pdetails, int sellerid, int prodid) {
		Product productdtails=pdao.getbyid(sellerid, prodid);
		System.out.println(pdetails);
		float cost=pdetails.getPrice();
		int size=pdetails.getQuantity();
		productdtails.setPrice(cost);
		productdtails.setQuantity(size);
		System.out.println(productdtails);
		pdao.save(productdtails);
		
		
	}

	@Override
	public List<Product> searchProduct(String productname) {
		// TODO Auto-generated method stub
		return pdao.searchproduct(productname);
	}
     
	
	  
	 

	
}
