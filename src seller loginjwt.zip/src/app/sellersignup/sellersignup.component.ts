import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import { Router } from '@angular/router';
import { Seller } from '../Seller';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {
  seller:Seller= new Seller();
  constructor(private database:SellerServiceService,private router: Router) { }

  ngOnInit(): void {
  }
  addSeller(){
    console.log(this.seller);
    this.database.createseller(this.seller)
    .subscribe(seller=>this.seller=seller);
    this.router.navigate(['sellerlogin']);
  }
onSubmit(form:NgForm){
    this.addSeller();
}
}
