import { Component, OnInit } from '@angular/core';
import { Product } from '../Items';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-updateitem',
  templateUrl: './updateitem.component.html',
  styleUrls: ['./updateitem.component.css']
})
export class UpdateitemComponent implements OnInit {
  product:Product=new Product();

  constructor(private up:SellerServiceService) { }

  ngOnInit(): void {
  }

  update()
  {
    this.up.updateItems(this.product).subscribe(product => this.product = product);
  }

  onSubmit()
  {
  this.update();
  alert("Items updated");
  }
}
