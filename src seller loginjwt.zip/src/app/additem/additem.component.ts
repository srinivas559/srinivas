import { Component, OnInit } from '@angular/core';
import { Product } from '../Items';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {
  product:Product=new Product();
  constructor(private adds:SellerServiceService) { }

  ngOnInit(): void {

  }
 
  onSubmit()
  {
this.adds.addItems(this.product).subscribe(product => this.product=product);
alert("Items added successfully");
  }
}
