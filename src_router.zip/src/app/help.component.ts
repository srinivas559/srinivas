import { Component } from '@angular/core';

@Component({
    selector: 'app-help123', //you can use any selector of your choice
    template: `<h2>Help</h2>`
  })
  export class HelpComponent { }