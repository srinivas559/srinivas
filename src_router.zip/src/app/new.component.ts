import { Component } from '@angular/core';
@Component({
selector : 'app-security',
template : '<h2>Srinivas</h2>'
})
export class newComponent{}